import http from "./httpService";
import { apiUrl } from "../utils/config";
import jwtDecode from "jwt-decode";
import { setJwt } from "./httpService";

const apiEndpoint = apiUrl + "/auth";
const tokenKey = "token";

setJwt(getJwtToken());

export async function login(email, password) {
  const { data: jwt } = await http.post(apiEndpoint, { email, password });
  localStorage.setItem(tokenKey, jwt);
  console.log(localStorage.getItem(tokenKey));
}
export function logout() {
  localStorage.removeItem(tokenKey);
}
export function LoginWithJwt(jwt) {
  localStorage.setItem(tokenKey, jwt);
}
export function getJwtToken() {
  return localStorage.getItem(tokenKey);
}
export function currentUser() {
  try {
    const jwt = localStorage.getItem(tokenKey);
    return jwtDecode(jwt);
  } catch (error) {
    return null;
  }
}
export default {
  login,
  logout,
  currentUser,
  LoginWithJwt,
  getJwtToken
};
