//import * as Sentry from "@sentry/browser";

function init() {
  // Sentry.init({
  //   dsn: "https://7a1afb67c43c44e88562a62eb0ca3a7a@sentry.io/5189286"
  // });
}

function log(error) {
  //
  console.error(error);
}

export default {
  init,
  log
};
