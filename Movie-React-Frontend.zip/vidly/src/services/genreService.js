import http from "./httpService";
import { apiUrl } from "../utils/config";

export function getGenres() {
  return http.get(apiUrl + "/genres");
}
