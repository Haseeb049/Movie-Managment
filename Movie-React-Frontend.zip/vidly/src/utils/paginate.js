import _ from "lodash";

const Paginate = (items, currentPage, PageSize) => {
  const startIndex = (currentPage - 1) * PageSize;
  return _(items)
    .slice(startIndex)
    .take(PageSize)
    .value();
};

export default Paginate;
