import React, { Component } from "react";
import Movies from "./components/movies";
import "./App.css";
import { ToastContainer } from "react-toastify";
import { Route, Switch, Redirect } from "react-router-dom";
import NavBar from "./components/layout/NavBar";
import NotFound from "./notFound";
import Customers from "./components/customers";
import Rentals from "./components/rentals";
import "./App.css";
import MovieForm from "./components/movieForm";
import Login from "./components/login";
import Register from "./components/Register";
import "react-toastify/dist/ReactToastify.css";
import { render } from "@testing-library/react";
import Logout from "./components/logout";
import auth from "./services/authService";
import ProtectedRoute from "./components/common/protectedRoutes";
class App extends Component {
  state = {};

  componentDidMount() {
    const user = auth.currentUser();
    this.setState({ user });
  }
  render() {
    const { user } = this.state;
    return (
      <div>
        <ToastContainer />
        <NavBar user={this.state.user} />
        <div className="content">
          <Switch>
            {/* <Route path="/newmovieform" component={MovieForm} /> */}
            <Route path="/login" component={Login} />
            <Route path="/logout" component={Logout} />
            <Route path="/register" component={Register} />
            <ProtectedRoute path="/movies/:id" component={MovieForm} />
            <Route
              path="/movies"
              render={props => <Movies {...props} user={this.state.user} />}
            />
            <Route path="/customers" component={Customers} />
            <Route path="/rentals" component={Rentals} />
            <Route path="/not-found" exact component={NotFound} />
            <Redirect from="/" exact to="/movies" />
            <Redirect to="/not-found" />
          </Switch>
        </div>
      </div>
    );
  }
}

export default App;
