import React, { Component } from "react";
import Like from "./common/like";
import Table from "./common/Table";
import { Link } from "react-router-dom";
import auth from "../services/authService";
class MoviesTable extends Component {
  columns = [
    {
      path: "title",
      label: "Title",
      content: movie => <Link to={`/movies/${movie._id}`}>{movie.title}</Link>
    },
    { path: "genre.name", label: "Genre" },
    { path: "numberInStock", label: "Stock" },
    { path: "dailyRentalRate", label: "Rate" },
    {
      key: "like",
      content: movie => (
        <Like onClick={() => this.props.onLike(movie)} liked={movie.liked} />
      )
    }
  ];
  deleteColumn = {
    key: "delete",
    content: movie => (
      <button
        className="btn btn-danger btn-small"
        onClick={() => this.props.onDelete(movie)}
      >
        Delete
      </button>
    )
  };
  constructor() {
    super();
    const user = auth.currentUser();
    if (user && user.isAdmin) {
      this.columns.push(this.deleteColumn);
    }
  }

  render() {
    const { movies, sortColumn, onSort } = this.props;
    return (
      <Table
        columns={this.columns}
        sortColumn={sortColumn}
        onSort={onSort}
        data={movies}
      />
    );
  }
}

export default MoviesTable;
