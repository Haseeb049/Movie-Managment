import React, { Component } from "react";
import { toast } from "react-toastify";
import { getMovies } from "../services/movieService";
import { getGenres } from "../services/genreService";
import MoviesTable from "./moviesTable";
import Pagination from "./common/pagination";
import Paginate from "../utils/paginate";
import ListGroup from "./common/listGroup";
import { Route, Redirect, Link, Switch } from "react-router-dom";
import Search from "./common/search";
import _ from "lodash";
import { deleteMovie } from "../services/movieService";

class Movies extends Component {
  state = {
    movies: [],
    genres: [],
    selectedGenre: null,
    currentPage: 1,
    pageSize: 4,
    sortColumn: { path: "title", order: "asc" }
  };
  style = {
    navlink: {
      marginBottom: "20px",
      marginTop: "-5px"
    },
    search: { width: "430px" }
  };
  async componentDidMount() {
    const { data } = await getGenres();
    const genres = [{ _id: "", name: "All Genres" }, ...data];

    const { data: movies } = await getMovies();
    this.setState({ movies: movies, genres });
  }

  handleDelete = async movie => {
    const originalMovies = this.state.movies;
    const movies = originalMovies.filter(m => m._id !== movie._id);
    this.setState({ movies });
    try {
      await deleteMovie(movie._id);
    } catch (ex) {
      if (ex.response && ex.response.status == 404)
        toast.error("Thi movie has already been deleted");

      this.setState({ movies: originalMovies });
    }
  };

  handleLike = movie => {
    const movies = [...this.state.movies];
    const index = movies.indexOf(movie);
    movies[index].liked = !movies[index].liked;
    this.setState(movies);
  };

  handlePageChange = page => {
    this.setState({ currentPage: page });
  };
  handleGenreSelect = genre => {
    this.setState({ selectedGenre: genre, currentPage: 1 });
  };

  handleSort = sortColumn => {
    this.setState({ sortColumn });
  };

  getPagedData = () => {
    const {
      pageSize,
      selectedGenre,
      currentPage,
      sortColumn,
      movies: allmovies
    } = this.state;

    const filtered =
      selectedGenre && selectedGenre._id
        ? allmovies.filter(m => m.genre._id === selectedGenre._id)
        : allmovies;

    const sorted = _.orderBy(filtered, [sortColumn.path], [sortColumn.order]);
    // it returns array of movies of current page
    const movies = Paginate(sorted, currentPage, pageSize);
    console.log(movies);
    return { totalCount: filtered.length, data: movies };
  };
  handleSearch = ({ currentTarget: input }) => {
    const movies = getMovies();
    console.log(movies);

    const searchedMovies = [];
    let available = false;
    let foundAtLeastOne = false;
    movies.map(movie => {
      // checking if particular movie is available
      available = _.includes(
        _.lowerCase(movie.title),
        _.lowerCase(input.value)
      );
      if (available === true) {
        searchedMovies.push(movie);

        foundAtLeastOne = true;
      }
      // if atleast one movie is found we will update for state
      if (foundAtLeastOne === true)
        this.setState({
          selectedGenre: null,
          currentPage: 1,
          movies: searchedMovies
        });
      // if input is empty we will update state to all movies
      if (input.value === "") this.setState({ movies: getMovies() });
    });
  };
  render() {
    const { length: count } = this.state.movies;
    const {
      pageSize,

      currentPage,
      sortColumn,

      genres
    } = this.state;

    //  console.log(movies);
    const { user } = this.props;
    const { totalCount, data: movies } = this.getPagedData();

    if (count === 0) return <p>There are no movies in Database</p>;
    return (
      <React.Fragment>
        <div className="row">
          <div className="col-md-3">
            <ListGroup
              selectedItem={this.state.selectedGenre}
              onItemSelect={this.handleGenreSelect}
              items={genres}
            />
          </div>
          <div className="col-md-4">
            {user && (
              <Link
                className="nav-item nav-link"
                to="/movies/new"
                style={this.style.navlink}
              >
                <button className="btn btn-primary">New Movie</button>
              </Link>
            )}

            <p>Showing {totalCount} movies in the database.</p>
            <div style={this.style.search}>
              <Search
                placeholder="Search..."
                name="search"
                onChange={this.handleSearch}
              />
            </div>
            <MoviesTable
              sortColumn={sortColumn}
              onSort={this.handleSort}
              movies={movies}
              onLike={this.handleLike}
              onDelete={this.handleDelete}
            />
            <div>
              <Pagination
                itemsCount={totalCount}
                pageSize={pageSize}
                onPageChange={this.handlePageChange}
                currentPage={currentPage}
              />
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default Movies;
