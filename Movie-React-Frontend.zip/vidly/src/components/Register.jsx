import React, { Component } from "react";
import Joi from "joi-browser";
import Form from "./common/Forms";
import * as userService from "../services/userService";
import authService from "../services/authService";
import auth from "../services/authService";
class Register extends Form {
  state = {
    data: {
      username: "",
      password: "",
      name: ""
    },
    errors: {}
  };
  style = {
    header: {
      marginRight: "350px",
      marginLeft: "460px"
    },
    body: { marginRight: "450px", marginLeft: "350px" }
  };
  schema = {
    username: Joi.string()
      .required()
      .label("Username")
      .email(),
    password: Joi.string()
      .required()
      .label("Password")
      .min(5),
    name: Joi.string()
      .required()
      .label("Name")
  };

  doSubmit = async () => {
    try {
      const response = await userService.register(this.state.data);
      auth.LoginWithJwt(response.headers["x-auth-token"]);
      window.location = "/";
    } catch (ex) {
      if (ex.response && ex.response.status === 400) {
        const errors = { ...this.state.errors };
        errors.username = ex.response.data;
        this.setState({ errors });
      }
    }
  };

  render() {
    //console.log(this.state.errors);
    return (
      <div>
        <h1 style={this.style.header}>Register</h1>
        <form style={this.style.body} onSubmit={this.handleSubmit} action="">
          {this.renderInput("username", "Username")}
          {this.renderInput("password", "Password", "password")}
          {this.renderInput("name", "Name")}
          {this.renderButton("Register ")}
        </form>
      </div>
    );
  }
}

export default Register;
