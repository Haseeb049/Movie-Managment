import React, { Component } from "react";
class Like extends Component {
  state = {};
  render() {
    let liked = this.props.liked;
    let classess = "fa fa-heart";
    if (!liked) classess += "-o";

    return (
      <i
        className={classess}
        aria-hidden="true"
        onClick={this.props.onClick}
      ></i>
    );
  }
}

export default Like;
