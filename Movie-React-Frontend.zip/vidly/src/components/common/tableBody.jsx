import React, { Component } from "react";
import _ from "lodash";
class TableBody extends Component {
  renderCell = (item, column) => {
    if (column.content) return column.content(item);
    // it returns that particular path value from a particular movie
    return _.get(item, column.path);
  };

  createKey = (item, column) => {
    return item._id + (column.path || column.key);
  };
  render() {
    const { data, columns } = this.props;

    return (
      <tbody>
        {/* item represents particular movie */}
        {data.map(item => (
          <tr key={item._id}>
            {/* column represents partiular column of table */}
            {columns.map(column => (
              <td key={() => this.createKey(item, column)}>
                {/* it renders particular cell of table */}
                {this.renderCell(item, column)}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    );
  }
}

export default TableBody;
